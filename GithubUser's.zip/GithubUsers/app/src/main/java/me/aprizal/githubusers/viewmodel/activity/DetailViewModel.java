package me.aprizal.githubusers.viewmodel.activity;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import me.aprizal.githubusers.repository.model.UsersResponseItem;
import me.aprizal.githubusers.repository.retrofit.ApiConfig;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailViewModel extends ViewModel {

    private final MutableLiveData<UsersResponseItem> _usersDetailResponseItem = new MutableLiveData<>();
    public LiveData<UsersResponseItem> getDetailUsersResponseItem(){
        return _usersDetailResponseItem;
    }

    private final MutableLiveData<Boolean> showLoading = new MutableLiveData<>();
    public LiveData<Boolean> getShowLoading() {
        return showLoading;
    }

    private final MutableLiveData<String> showToast = new MutableLiveData<>();
    public LiveData<String> getShowToast(){
        return showToast;
    }

    public void setDetailUser(String login){
        showLoading.setValue(true);
        Call<UsersResponseItem> usersResponseItemCall = ApiConfig.getApiService().getDetailUsers(login, "token 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");
        usersResponseItemCall.enqueue(new Callback<UsersResponseItem>() {
            @Override
            public void onResponse(@NonNull Call<UsersResponseItem> call, @NonNull Response<UsersResponseItem> response) {
                showLoading.setValue(false);
                if (response.isSuccessful()){
                    if (response.body() !=null){
                        _usersDetailResponseItem.setValue(response.body());
                    }
                }else {
                    if (response.body() !=null){
                        showToast.setValue("Failure Detail Users " + login);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<UsersResponseItem> call, @NonNull Throwable t) {
                showLoading.setValue(false);
                showToast.setValue("Failure Detail Users " +t.getMessage());
            }
        });
    }
}
